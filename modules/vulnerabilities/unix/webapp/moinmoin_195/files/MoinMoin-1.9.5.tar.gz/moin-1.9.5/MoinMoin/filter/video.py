# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - video/* file Filter

    @copyright: 2006 MoinMoin:ThomasWaldmann
    @license: GNU GPL, see COPYING for details.
"""

def execute(indexobj, filename):
    """ Video data filtering not implemented yet.

        TODO: maybe extract some meta information from some popular video formats.
    """
    return u""

