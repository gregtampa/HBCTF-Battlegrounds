# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - XMLRPC CLI Scripts

    @copyright: 2006 MoinMoin:AlexanderSchremmer
    @license: GNU GPL, see COPYING for details.
"""

from MoinMoin.util import pysupport

# create a list of extension scripts from the subpackage directory
modules = pysupport.getPackageModules(__file__)

