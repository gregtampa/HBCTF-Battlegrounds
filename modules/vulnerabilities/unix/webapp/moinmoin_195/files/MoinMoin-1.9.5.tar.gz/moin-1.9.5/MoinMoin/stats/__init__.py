# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - Statistics

    @copyright: 2002-2004 Juergen Hermann <jh@web.de>
    @license: GNU GPL, see COPYING for details.
"""

