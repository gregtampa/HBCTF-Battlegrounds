# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - Package Initialization

    Subpackage containing e-mail support code.

    @copyright: 2006 MoinMoin:ThomasWaldmann
    @license: GNU GPL, see COPYING for details.
"""

